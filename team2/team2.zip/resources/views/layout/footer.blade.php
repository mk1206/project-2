<footer>
	<div class="footer">
		ⓒ 2023. team2 Co. all rights reserved.
	</div>
</footer>