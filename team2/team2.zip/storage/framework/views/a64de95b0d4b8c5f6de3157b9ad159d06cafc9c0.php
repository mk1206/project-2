

<?php $__env->startSection('title','mypage'); ?>
    

<?php $__env->startSection('main'); ?>

<div class="mypage-grid" id="mypageGrid">
    <div class="mypage-content" id="mypageContent">
            <div class="mypage-board-show-btn">내가 쓴 게시글</div>
            <div class="mypage-comment-show-btn">내가 쓴 댓글</div>
        
            <div class="mypage-boards-part">
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                    $previous_item = $index - 1;
                    $present_item = $index - 0;
                    // $board_date = $data[$present_item]->created_at;
                    // $timestamp = strtotime($board_date);
                    // $create_date = date('y-m-d', $timestamp);
                    ?>
                    <?php if( $index >= 1): ?>
                        <?php if($data[$present_item]->created_at != $data[$previous_item]->created_at): ?>
                        <div class="mypage-date-today">
                            <span class="mypage-board-date"><?php echo e($item->created_at); ?></span>
                        </div>
                        <a href="<?php echo e(route('board.show', ['board' => $item->board_id])); ?>">
                            <div class="mypage-boardbox">
                                <div class="mypage-bord-title"><?php echo e(Str::limit($item->board_title, 30, '...')); ?></div>
                                <div class="mypage-bord-detailbox"><?php echo e(Str::limit($item->board_content, 75, '...')); ?></div>
                            </div>
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(route('board.show', ['board' => $item->board_id])); ?>">
                            <div class="mypage-boardbox">
                                <div class="mypage-bord-title"><?php echo e(Str::limit($item->board_title, 30, '...')); ?></div>
                                <div class="mypage-bord-detailbox"><?php echo e(Str::limit($item->board_content, 75, '...')); ?></div>
                            </div>
                        </a>
                        <?php endif; ?>
                    <?php else: ?>
                    <div class="mypage-date-today">
                        <span class="mypage-board-date"><?php echo e($item->created_at); ?></span>
                    </div>
                    <a href="<?php echo e(route('board.show', ['board' => $item->board_id])); ?>">
                        <div class="mypage-boardbox">
                            <div class="mypage-bord-title"><?php echo e(Str::limit($item->board_title, 30, '...')); ?></div>
                            <div class="mypage-bord-detailbox"><?php echo e(Str::limit($item->board_content, 75, '...')); ?></div>
                        </div>
                    </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div> 작성한 게시글이 없습니다. </div>
                <?php endif; ?>
            </div>

            <div class="mypage-date-today">
                <span class="mypage-board-date"></span>
            </div>
            <div class="mypage-boards-part">
                <div class="mypage-boardbox">
                    <span class="mypage-boardbox-date">2023-12-12</span>
                    <div class="mypage-bord-title"> 댓글 view 제목입니다.</div>
                    <div class="mypage-bord-detailbox">상세내용입니다.</div>
                </div>
                <div class="mypage-boardbox">
                    <span class="mypage-boardbox-date">2023-12-12</span>
                    <div class="mypage-bord-title">제목입니다.</div>
                    <div class="mypage-bord-detailbox">상세내용입니다.</div>
                </div>
                <div class="mypage-boardbox">
                    <span class="mypage-boardbox-date">2023-12-12</span>
                    <div class="mypage-bord-title">제목입니다.</div>
                    <div class="mypage-bord-detailbox">상세내용입니다.</div>
                </div>
                <div class="mypage-boardbox">
                    <span class="mypage-boardbox-date">2023-12-12</span>
                    <div class="mypage-bord-title">제목입니다.</div>
                    <div class="mypage-bord-detailbox">상세내용입니다.</div>
                </div>
            </div>
        <div class="mypage-btn-plus">더보기</div>
        
        <a href="<?php echo e(route('insert')); ?>">
            <img src="/img/plusbtn.png" alt="" class="mypage-insert-btn">
        </a>
    </div>

    
    <div class="mypage-content2" id="mypageContent2">
        <form action="/userinfoupdate" class="user-info-modify" method="POST" id="userinfo_form" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div id="UserInfoModify">
                <label for="profilephoto">
                    <div class="profile-photo-btn" style="background-image: url(/user_img/<?php echo e($user_info[0]->user_img); ?>);"></div>
                    <span id="user_img_name"></span>
                </label>
                <input type="file" accept="image/*" style="display: none;" id="profilephoto" name="user_img">
                <span id="user-img-url"></span>
                
                <br>
                <label for="profilephoto" class="user-info-btn"> 사진 변경 </label>
                <div class="user-info-btn" onclick="userimgremove(); return false;"> 삭제 </div>
                <input type="hidden" name="imgFlg" id="imgflg">
                <br>
                <label for="usermodifyname">닉네임 수정</label>
                <div class="user-info-btn-chk" onclick="nameChange(); return false;"> 닉네임 중복 확인 </div>
                <input type="text" id="usermodifyname" name="user_name" value="<?php echo e($user_info[0]->user_name); ?>">
                
                <label>현재 주소지</label>
                <div class="user-now-address"><?php echo e($user_info[0]->user_address); ?></div>
                <label>주소 변경</label>
                <div class="adress-box">
                    <input class="adress-box-a" type="text" id="sample4_postcode" placeholder="우편번호" name="user_adress_num" readonly>
                    <input type="button" onclick="sample4_execDaumPostcode()" value="우편번호 찾기" class="user-info-btn"><br>
                    <span id="guide" style="color:#999;display:none"></span>
                    <input class="adress-box-b" type="text" id="sample4_roadAddress" name="user_adress" placeholder="도로명주소" readonly>
                    <br>
                    <input class="adress-box-b" type="text" id="sample4_detailAddress" name="user_adress_address" placeholder="상세주소">
                </div>
                <div class="mypage-btn-line-modify">
                    <button type="button" class="mypage-btn" onclick="userinfoupdate(); return false;">수정완료</button>
                    
                </div>
            </div>
        </form>
    </div>

    <div class="mypage-mainbar">
        <div class="mypage-btn-layout">
            <div class="mypage-btn-line">
                <div class="mypage-btn" onclick="userinforupdate(); return false;">정보수정</div>
                <a href="<?php echo e(route('todaytimeline.get')); ?>"><div class="mypage-btn">타임라인</div></a>
            </div>
            <div class="mypage-btn2" onclick="userboardshow(); return false;">나의 게시물</div>
        </div>

        <div class="mypage-tag-title" id="mypageTagTitle">
            <div class="mypage-hashtag-title">
                <img src="/img/star.png" alt="">
                내가 찜한 관심 태그
            </div>
            <div class="mypage-hashtag" id="mypageHashtag">
            <?php $__empty_1 = true; $__currentLoopData = $user_hashtag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div id="favoriteHashtagId<?php echo e($item->favorite_tag_id); ?>">
                    <span id="favoritehashtext<?php echo e($item->favorite_tag_id); ?>" value="<?php echo e($item->favorite_tag_id); ?>"><?php echo e($item->hashtag_name); ?></span>
                    <span onclick="favoritehashdelete(<?php echo e($item->favorite_tag_id); ?>); return false;">x</span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div> 관심태그로 등록한 해시태그가 없습니다.</div>
            <?php endif; ?>
            </div>
            <div class="favorite-tag-plus" id="addallfavoritetag">
                관심태그 추가하기
            </div>

        </div>
    </div>
</div>







<div class="UserboardModal" id="UserboardModal">
    <div>
        <div class="mypage-content-modal" id="mypageContentModal">
            <div onclick="mypagemodalclosebtn(); return false;" class="mypage-modal-close-btn">x</div>
            <div class="modal-board-show-btn">
                <div class="mypage-board-modal-btn">내가 쓴 게시글</div>
                <div class="mypage-comment-modal-btn">내가 쓴 댓글</div>
            </div>
            <div class="mypage-boards-part">
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                    $previous_item = $index - 1;
                    $present_item = $index - 0;
                    ?>
                    <?php if( $index >= 1): ?>
                        <?php if($data[$present_item]->created_at != $data[$previous_item]->created_at): ?>
                        <div class="mypage-date-today">
                            <span class="mypage-board-date"><?php echo e($item->created_at); ?></span>
                        </div>
                        <a href="<?php echo e(route('board.show', ['board' => $item->board_id])); ?>">
                            <div class="mypage-boardbox-modal">
                                <div class="mypage-bord-title"><?php echo e($item->board_title); ?></div>
                                <div class="mypage-bord-detailbox"><?php echo e($item->board_content); ?></div>
                            </div>
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(route('board.show', ['board' => $item->board_id])); ?>">
                            <div class="mypage-boardbox-modal">
                                <div class="mypage-bord-title"><?php echo e($item->board_title); ?></div>
                                <div class="mypage-bord-detailbox"><?php echo e($item->board_content); ?></div>
                            </div>
                        </a>
                        <?php endif; ?>
                    <?php else: ?>
                    <div class="mypage-date-today">
                        <span class="mypage-board-date"><?php echo e($item->created_at); ?></span>
                    </div>
                    <a href="<?php echo e(route('board.show', ['board' => $item->board_id])); ?>">
                        <div class="mypage-boardbox-modal">
                            <div class="mypage-bord-title"><?php echo e($item->board_title); ?></div>
                            <div class="mypage-bord-detailbox"><?php echo e($item->board_content); ?></div>
                        </div>
                    </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div> 작성한 게시글이 없습니다. </div>
                <?php endif; ?>
            </div>

        
            <div class="mypage-btn-plus">더보기</div>
            
            <a href="<?php echo e(route('insert')); ?>">
                <img src="/img/plusbtn.png" alt="" class="mypage-insert-btn">
            </a>
        </div>
    </div>
</div>
<script src="/js/mypage.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/mypage.blade.php ENDPATH**/ ?>