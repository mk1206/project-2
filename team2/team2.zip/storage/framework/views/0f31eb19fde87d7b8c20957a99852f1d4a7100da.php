

<?php $__env->startSection('title','Community'); ?>

<?php $__env->startSection('main'); ?>
<main class="">    
    <div class="slider-container">
        <a href="" class="community_a"><img class="community_icon" src="../img/top.png" alt=""></a>
        <a href="<?php echo e(route('board.create')); ?>" class="community_aplus"><img class="community_icon" src="../img/plusicon.png" alt=""></a>
        <div class="community_headline">
            <h2>🔥HOT 게시글</h2>
            <a href="<?php echo e(route('categoryboard')); ?>" class="cate_btn">커뮤니티</a>            
        </div>		
	
		
        <div class="slider" id="slider">
            <?php $__empty_1 = true; $__currentLoopData = $data[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('board.show',['board'=>$item->board_id])); ?>">
                <div class="slide a-bordergo-hover">
                    <div>
                        <div><?php echo e($item->board_title); ?></div>
                        <div><?php echo e($item->board_content); ?></div>
                    </div>
                    <div class="community_bottom">
                        <div>
                            조회수 <?php echo e($item->board_hits); ?>

                        </div>
                        <div>
                            댓글 <?php echo e($item->comments->count()); ?>

                        </div>
                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                게시글이 없습니다.
            <?php endif; ?>
        </div>
    </div>    
        
    <div class="favorite_slider-container"> 
        <div class="favorite_slider">
            <?php $__empty_1 = true; $__currentLoopData = $data[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="favorite_slide">
                <div class="favorite_slide-name">
                    <?php echo e($item->pandemic_name); ?>

                </div> 
                <div class="community_content">
                    <?php echo e($item->pandemic_symptoms); ?>

                </div>            
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?>
        </div>
    </div>    
    <div class="community_tag_hidden">
        <div class="board-bc-gray">
        <div class="community_tag_container"> 
            <div class="">
                <h2>⭐관심 태그</h2>                    
            </div>
            <div style="margin-left: 30px;">
                <?php $__empty_1 = true; $__currentLoopData = $data[4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <span><?php echo e($item->hashtag_name); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                등록된 관심태그가 없습니다
            <?php endif; ?>
            </div>
            <div class="community_tag bordergo-hover">
                <?php $__empty_1 = true; $__currentLoopData = $data[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('board.show',['board'=>$item->board_id])); ?>">
                    <div>
                        <div style="margin-bottom: 30px;"><?php echo e($item->board_title); ?></div>
                        <div><?php echo e($item->board_content); ?></div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
            </div>
            <div class="community_more_container">
                <button class="community_more">더보기</button>
            </div>
        </div>
    </div>
    <div class="community_tag_container">        
        <div class="community_headline">
            <h2>최근 게시글</h2>                     
        </div>
        <div class="community_tag border-line-color-gray bordergo-hover">
            <?php $__empty_1 = true; $__currentLoopData = $data[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('board.show',['board'=>$item->board_id])); ?>">
                <div>
                    <div style="margin-bottom: 30px"><?php echo e($item->board_title); ?></div>
                    <div><?php echo e($item->board_content); ?></div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                게시글이 없습니다.
            <?php endif; ?>
        </div>
        <div class="community_more_container">
            <button class="community_more">더보기</button>
        </div>
    </div>
    
</main>
<script src="/js/community.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/community.blade.php ENDPATH**/ ?>