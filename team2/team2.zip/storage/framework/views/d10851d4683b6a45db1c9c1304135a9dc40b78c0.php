

<?php $__env->startSection('title','Categoryboard'); ?>

<?php $__env->startSection('main'); ?>
<div class="last_main" id='category-board'>
    <a href="" class="community_a"><img class="community_icon" src="../img/top.png" alt=""></a>
        <a href="<?php echo e(route('board.create')); ?>" class="community_aplus"><img class="community_icon" src="../img/plusicon.png" alt=""></a>
    <div class="last_headline">
        <h2><?php echo e($data[2][0]->category_name); ?></h2>
        <div class="dropdown">
            <button class="cate_btn" onclick="toggleDropdown()">정렬</button>
            <div class="dropdown-content" id="myDropdown">
                <form method="get" id="category_id_form">
                    <?php echo csrf_field(); ?>
                    <?php $__empty_1 = true; $__currentLoopData = $data[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="board-mouse-cursor" onclick="showBoard(<?php echo e($item->category_id); ?>); return false;"><?php echo e($item->category_name); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    
    <?php $__currentLoopData = $data[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="last_container">
        <div class="last_user">  
                        
             <img class="community_icon" src="<?php echo e(asset('user_img/' . optional($item->user)->user_img)); ?>" class="board_nic_img" alt="User Image">            
            
            <div class="board_nic_text">
                <div>
                <?php echo e(optional($item->user)->user_name); ?>

                </div>
                <div>
                <?php echo e($item->created_at); ?>

                </div>
            </div>
        </div> 
        <div style="width: 280px; margin-left: 10px;">
            <?php echo e($item->board_title); ?>

        </div> 
        <a href="<?php echo e(route('board.show',['board'=>$item->board_id])); ?>" class="community_content">
            <div class="last_content">
            
                <?php echo e($item->board_content); ?>

                                
            </div>  
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>



<div class="pagination">    
    <?php if($data[0]->currentPage() > 1): ?>
        <a href="<?php echo e($data[0]->url(1)); ?>">&lt;&lt;</a>
        <a href="<?php echo e($data[0]->previousPageUrl()); ?>"> 이전</a>
    <?php endif; ?>

    <?php for($i = max(1, $data[0]->currentPage() - 2); $i <= min($data[0]->lastPage(), $data[0]->currentPage() + 3); $i++): ?>
        <?php if($i == $data[0]->currentPage()): ?>
            <span class="pagination-current"><?php echo e($i); ?></span>
        <?php else: ?>
            <a href="<?php echo e($data[0]->url($i)); ?>" class="pagination-link"><?php echo e($i); ?></a>
        <?php endif; ?>
    <?php endfor; ?>

    <?php if($data[0]->currentPage() < $data[0]->lastPage()): ?>
        <a href="<?php echo e($data[0]->nextPageUrl()); ?>">다음 </a>
        <a href="<?php echo e($data[0]->url($data[0]->lastPage())); ?>">&gt;&gt;</a>
    <?php endif; ?>
</div>

<script src="/js/categoryboard.js"></script> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/categoryboard.blade.php ENDPATH**/ ?>