<footer>
	<div class="footer">
		ⓒ 2023. team2 Co. all rights reserved.
	</div>
</footer><?php /**PATH D:\workspace\2_project\team2\resources\views/layout/footer.blade.php ENDPATH**/ ?>