

<?php $__env->startSection('title','Hotboard'); ?>

<?php $__env->startSection('main'); ?>

<main class="last_main">
    <div class="last_headline">
        <h2>핫게시글</h2>        
    </div>
    <div class="last_container">
        <div class="last_user">
            <img src="../img/f-img.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    
    <div class="last_container">
        <div class="last_user">
            <img src="../img/f-img.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    <div class="last_container">
        <div class="last_user">
            <img src="../img/f-img.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    <div class="last_container">
        <div class="last_user">
            <img src="../img/f-img.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/hotboard.blade.php ENDPATH**/ ?>