

<?php $__env->startSection('title','timeline'); ?>
    

<?php $__env->startSection('main'); ?>
<div class="timelinemain">
    <div class="mypage-first">
        <div class="calendarBtn" id="calendarBtn" onclick="calendarshow(); return false;"></div>
        <div class="maincalendar calendarNone" id="calendarOpen">
            <table class="Calendar">
                <thead>
                    <tr>
                        <td onclick="prevCalendar(); return false;" style="cursor:pointer;">&#60;</td>
                        <td colspan="5">
                            <span id="calYear"></span>년
                            <span id="calMonth"></span>월
                        </td>
                        <td onclick="nextCalendar(); return false;" style="cursor:pointer;">&#62;</td>
                    </tr>
                    <tr>
                        <td>일</td>
                        <td>월</td>
                        <td>화</td>
                        <td>수</td>
                        <td>목</td>
                        <td>금</td>
                        <td>토</td>
                    </tr>
                </thead>

                <tbody>
                </tbody>
            </table>
        </div>
        <br>
        
    </div>

    <div class="mypage-second" id="mypageSecond">
        
    </div>

    <div class="mypage-third">
        <div class="recordsection" id="recordDeleteTest">
            <input type="hidden" value="<?php echo e($result_count); ?>" id="recordTurn">
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <img src="/img/circle.png" class="record-circle-img" id="recordCircleImg">
                <div class="user-record" id="userRecord">
                    <span class="record-time"><?php echo e($item->created_at); ?></span>
                    <div class="record-delete-btn" onclick="recorddeletemodalopen(<?php echo e($item->record_id); ?>); return false;">X</div>
                    <br>
                    <span class="recordtext"><?php echo e($item->symptom_name); ?> </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="none-recordtext"> 오늘은 검색기록이 없어요!</div>
            <?php endif; ?>
            <div class="none-recordtext notice-no-data" id="noticeNoData"> 오늘은 검색기록이 없어요!</div>
        </div>
    </div>

    <div class="mypage-fourth" id="mypageFourth">
        <div id="recordDeleteModal">
            <div class="mypage-delete-modal">
                <div class="delete-message">
                삭제하시겠습니까?
                </div>
                <div>
                    <div class="record-delete-cancel" onclick="deletemodalclose(); return false;">취소</div>
                    <div class="record-delete-ok" onclick="recorddeletebtn(); return false;">확인</div>
                </div>
            </div>
        </div>
    </div>

</div>
<script src="/js/timeline.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/timeline.blade.php ENDPATH**/ ?>