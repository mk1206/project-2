

<?php $__env->startSection('title', 'main'); ?>

<?php $__env->startSection('main'); ?>
<main class="wrapper">
	<div class="container" id="part-display">
		<br>
		<div style="color: #2C2B71" class="text-center bc-purple">
			<br><br>
			<div><span class="text-part">#부위</span>를 선택해 주세요</div>
			<br><br>
			<div class="part-box">
				<?php $__empty_1 = true; $__currentLoopData = $part; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div onclick="partCheck(<?php echo e($item->part_id); ?>); return false;"><?php echo e($item->part_name); ?></div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<div>추가 될 예정입니다. 기다려주세용</div>
				<?php endif; ?>
			</div>
			<br><br>
		</div>
	</div>
	<div class="container" id="symptom-display">
		<br>
		<div style="color: #2C2B71" class="text-center bc-purple">
			<br><br>
			<div><span class="text-part">#증상</span>을 선택해 주세요</div>
			<br><br>
			<div class="part-box" id="symptom-box">
				
			</div>
			<br><br>
		</div>
	</div>
	<div class="container" id="disease-display">
		<br>
		<div style="background-color: #F9F5F0" class="text-center">
			<br><br>
			<div id="diesase-name"></div>
			<br><br>
			<div style="font-weight: 500" id="diesase-info"></div>
			<br><br>
			<div id="map-display"><div id="map" style="width:100%; height:350px;"></div></div>
			<div class="display-flex">
				<a href="<?php echo e(route('main.get')); ?>" class="check-button">다시 검사</a>
				<span id="hospital" class="check-button">병원 찾기</span>
				
			</div>
		</div>
	</div>
</main>
	<script type="text/javascript" src="//dapi.kakao.com/v2/maps/sdk.js?appkey=6b402b118a5747fb73298eeccdc8b838&libraries=services"></script>
	<script src="../js/main.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/main.blade.php ENDPATH**/ ?>