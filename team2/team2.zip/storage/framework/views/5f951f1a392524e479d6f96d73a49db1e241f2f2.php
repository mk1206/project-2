<header>
	<?php if(request()->url() !== 'http://127.0.0.1:8000/login' && request()->url() !== 'http://127.0.0.1:8000/regist'): ?>
	<div class="container">
		<div class="inmypageheader">
			<div style="color: rgb(182, 182, 182)" class="div-margin font-small">
				<div id="time-year"></div>
				<div id="time-day"></div>
			</div>
			<div style="color: rgb(182, 182, 182)" class="mypagegohome">
				<a href="<?php echo e(route('main.get')); ?>">
				<span class="gohome header-margin-top">HOME</span>
				</a>
			</div>
		</div>
	<?php else: ?>
	<div class="mini-container">
	<?php endif; ?>
	<?php if(auth()->guard()->check()): ?>
		<div class="display-flex">
			<?php if(request()->url() !== 'http://127.0.0.1:8000/login' && request()->url() !== 'http://127.0.0.1:8000/regist'): ?>
				<div class="div-display-lnlineBlock display-none">
					<a href="<?php echo e(route('main.get')); ?>" class="gohome">HOME</a>
				</div>
			<?php else: ?>
				<div class="div-display-lnlineBlock div-margin-auto">
					<a href="<?php echo e(route('main.get')); ?>" class="gohome">HOME</a>
				</div>
			<?php endif; ?>
			<?php if(request()->url() !== 'http://127.0.0.1:8000/login' && request()->url() !== 'http://127.0.0.1:8000/regist'): ?>
				<div class="display-flex-center">
					<div style="margin-right: 10px" class="div-display-lnlineBlock"><img src="../user_img/<?php echo e(session('user_img')); ?>" alt="" class="btn-img b-radius"></div>
					<div class="div-display-lnlineBlock">
						<a href="/mypage"><span class="font-weight font-color"><?php echo e(session('user_name')); ?></span>님 안녕하세요</a>
						<?php if(request()->url() !== 'http://127.0.0.1:8000/mypage'): ?>
							<a href="/mypage" class="display-flex font-small">
								<span>welcome</span>
								<span class="font-color">마이페이지 이동</span>
							</a>
						<?php else: ?>
							<a href="<?php echo e(route('logout.get')); ?>" class="display-flex font-small">
								<span class="font-color">로그아웃</span>
							</a>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php if(auth()->guard()->guest()): ?>
		<div class="display-flex">
			<?php if(request()->url() !== 'http://127.0.0.1:8000/login' && request()->url() !== 'http://127.0.0.1:8000/regist'): ?>
				<div class="div-display-lnlineBlock display-none">
					<a href="<?php echo e(route('main.get')); ?>" class="gohome">HOME</a>
				</div>
			<?php else: ?>
				<div class="div-display-lnlineBlock div-margin-auto">
					<a href="<?php echo e(route('main.get')); ?>" class="gohome">HOME</a>
				</div>
			<?php endif; ?>
			<?php if(request()->url() !== 'http://127.0.0.1:8000/login' && request()->url() !== 'http://127.0.0.1:8000/regist'): ?>
				<div class="display-flex-center">
					<div style="margin-right: 10px" class="div-display-lnlineBlock"><img src="../img/default_f.png" alt="" class="btn-img b-radius"></div>
					<div class="div-display-lnlineBlock">
						<a href="<?php echo e(route('login.get')); ?>"><span class="font-weight font-color">로그인</span>을 해주세요.</a>
						<?php if(request()->url() !== 'http://127.0.0.1:8000/mypage'): ?>
							<a href="<?php echo e(route('login.get')); ?>" class="display-flex font-small">
								<span>welcome</span>
							</a>
						<?php else: ?>
							<a href="<?php echo e(route('logout.get')); ?>" class="display-flex font-small">
								<span class="font-color">로그아웃</span>
							</a>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>

		<?php if(request()->url() !== 'http://127.0.0.1:8000/login' && request()->url() !== 'http://127.0.0.1:8000/regist'
		&& request()->url() !== 'http://127.0.0.1:8000/mypage' && request()->url() !== 'http://127.0.0.1:8000/categoryboard'
		&& !Str::contains(request()->url(), 'boardcategory') && !Str::contains(request()->url(), 'board/')): ?>
			<div class="container-category display-flex-around div-padding">
				<a href="<?php echo e(route('main.get')); ?>" class="div-display-lnlineBlock main-line-height">증상 검색</a>
				<a href="<?php echo e(route('board.index')); ?>" class="div-display-lnlineBlock main-line-height">커뮤니티</a>
				<a href="<?php echo e(route('todaytimeline.get')); ?>" class="div-display-lnlineBlock main-line-height">타임라인</a>
			</div>
		<?php endif; ?>
		<?php if(request()->url() === 'http://127.0.0.1:8000/categoryboard' || Str::contains(request()->url(), 'board/') || Str::contains(request()->url(), 'boardcategory')): ?>
			<div class="container-category display-flex-around div-padding">
				<a href="" class="div-display-lnlineBlock main-line-height">최근 게시글</a>
				<a href="" class="div-display-lnlineBlock main-line-height">핫게시글</a>
				<a href="" class="div-display-lnlineBlock main-line-height">관심태그</a>
				<a href="" class="div-display-lnlineBlock main-line-height">카테고리</a>
			</div>
		<?php endif; ?>
	</div>
</header><?php /**PATH D:\workspace\2_project\team2\resources\views/layout/header.blade.php ENDPATH**/ ?>