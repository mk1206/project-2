

<?php $__env->startSection('title','Insert'); ?>

<?php $__env->startSection('main'); ?>

<main class="insert_main">
	<div class="insert_hidden_container">
		<form class="detail_form" method="POST"  action="<?php echo e(route('board.store')); ?>" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			
			<div class="insert_container">
				<div class="insert_img">
					<label for="file0">
						<img id="preview0" src="<?php echo e(asset('img/plus.png')); ?>" alt="">
					</label>
					<input type="file" name="board_img[]" id="file0" style="display:none;" onchange="previewImage('file0', 'preview0')" accept="image/*" >
					<label for="file1">
						<img id="preview1" src="<?php echo e(asset('img/plus.png')); ?>" alt="">
					</label>
					<input type="file" name="board_img[]" id="file1" style="display:none;" onchange="previewImage('file1', 'preview1')" accept="image/*" >
					<label for="file2">
						<img id="preview2" src="<?php echo e(asset('img/plus.png')); ?>" alt="">
					</label>
					<input type="file" name="board_img[]" id="file2" style="display:none;" onchange="previewImage('file2', 'preview2')" accept="image/*" >
				</div>
				
				<div class="insert_select_container">
					<select name="category_id" id="category_id" class="insert_select">						
						<option value="1">자유게시판</option>
						<option value="2">정보 게시판</option>
						<option value="3">친목 게시판</option>
						<option value="4">질문 게시판</option>
					</select>
				</div>	
			
			
				<div class="insert_input_container">
					<label for="board_title" class="">제목</label><br>
					<input type="text" class="insert_input" id="board_title" name="board_title" required>			  
				</div>
				
				<div class="insert_textarea_container">
					<label for="board_content" >내용</label><br>			  
					<textarea name="board_content" id="board_content" class="insert_textarea" required ></textarea>
				</div>				
				<div class="insert_hashtag_container">
					<label for="hashtag" class="label_hashtag">#해시태그</label>
					<input type="text" class="insert_hashtag" id="hashtag" name="hashtag">
					<button type="button" id="toggleHashtagsBtn" onclick="toggleHashtags()">해시태그 펼치기/접기</button>
                    
                    <!-- Hidden container for hashtag data -->
                    <div id="hiddenHashtags" style="display: none;">
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<span class='tag' data-tag="<?php echo e($item->hashtag_name); ?>"><?php echo e($item->hashtag_name); ?></span>
    					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>	
					
				</div>
			</div>
			<div class="insert_bottom_button">
				<button class="insert_btn"><a href="<?php echo e(url()->previous()); ?>">취소</a></button>			
				<button type="submit" class="insert_btn">작성완료</button>	
			</div>				
		</form>		
	</div>		
</main>
       
<script src="/js/insert.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/insert.blade.php ENDPATH**/ ?>