

<?php $__env->startSection('title','Lastboard'); ?>

<?php $__env->startSection('main'); ?>

<main class="last_main">
    <a href="" class="community_a"><img class="community_icon" src="../img/top.png" alt=""></a>
    <a href="" class="community_aplus"><img class="community_icon" src="../img/plusicon.png" alt=""></a>
    <div class="last_headline">
        <h2>자유게시판</h2>
        <button type="submit" class="btn_last">
            정렬
        </button>
    </div>
    <div class="last_container">
        <div class="last_user">
            <img class="community_icon"  src="../img/default_f.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    
    <div class="last_container">
        <div class="last_user">
            <img class="community_icon"  src="../img/default_f.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    <div class="last_container">
        <div class="last_user">
            <img class="community_icon"  src="../img/default_f.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    <div class="last_container">
        <div class="last_user">
            <img class="community_icon"  src="../img/default_f.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    <div class="last_headline">
        <h2>질문게시판</h2>        
    </div>
    <div class="last_container">
        <div class="last_user">
            <img class="community_icon"  src="../img/default_f.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    
    <div class="last_container">
        <div class="last_user">
            <img class="community_icon"  src="../img/default_f.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    <div class="last_container">
        <div class="last_user">
            <img class="community_icon"  src="../img/default_f.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
    <div class="last_container">
        <div class="last_user">
            <img class="community_icon"  src="../img/default_f.png" alt="" class="board_nic_img">                               
            <div class="board_nic_text">
                <div>
                    닉네임
                </div>
                <div>
                    작성일자
                </div>
            </div>
        </div> 
        <div>
            제목
        </div> 
        <div class="last_content">
            내용
        </div>  
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/lastboard.blade.php ENDPATH**/ ?>