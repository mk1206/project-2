

<?php $__env->startSection('title','Detail'); ?>

<?php $__env->startSection('main'); ?>

<main class="last_main">
    
	
	<div class="detail_container">		
        <div class="detail_hidden_container">
            <div class="last_user">                
                <img class="community_icon" src="<?php echo e(asset('user_img/' . optional($data->user)->user_img)); ?>" alt="">                                  
                <div class="board_nic_text">
                    <div>
                    <?php echo e(optional($data->user)->user_name); ?>

                    </div>
                    <div>
                        <?php echo e($data->created_at); ?>

                    </div>
                </div>
            </div> 
            <div>           
                <p><?php echo e($data->board_title); ?></p>
            </div>         
            <div class="detail_content">
            <?php $__currentLoopData = $data->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="detail_board_content">
                <img src="/board_img/<?php echo e($image->img_address); ?>" alt="Board Image">
            </div>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
                <br>
                <div>
                <?php echo e($data->board_content); ?>                
                </div>                
            </div>
            <div>                
            <?php $__currentLoopData = optional($data->hashtag)->hashtag_name ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hashtag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><?php echo e($hashtag->hashtag_name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="detail_bottom_button">
        <form class="detail_form" action="<?php echo e(route('board.destroy', ['board' => $data->board_id])); ?>" method="POST" id="deleteForm" onsubmit="return confirm('정말로 삭제하시겠습니까?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <?php if(Auth::id() === $data->user->id): ?>
                <a href="<?php echo e(route('categoryboard')); ?>" class="a_cancel">목록</a>
                <a href="<?php echo e(route('board.edit', ['board' => $data->board_id])); ?>" class="a_update">수정</a>
                <button type="submit" class="d_btn">삭제</button>
            <?php else: ?>
                <a href="<?php echo e(route('categoryboard')); ?>" class="a_cancel">목록</a>
            <?php endif; ?>         
        </form>
    </div>
   
    <div class="detail_comment">
        <div class="comment_bottom">
        <p>댓글<?php echo e(count($data->comments ?? [])); ?>개</p>
        </div>
        <ul>
        <?php $__currentLoopData = $data->comments ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <div class="last_user">
                    
                <img class="community_icon" src="<?php echo e(asset('user_img/' . optional($comment->user)->user_img)); ?>" class="board_nic_img" alt="">
                        
                    <div class="board_nic_text">
                        <div>
                            <?php echo e(optional($comment->user)->user_name); ?>

                        </div>
                        <div>
                            <?php echo e($comment->created_at); ?>

                        </div>
                    </div>
                </div>
                <div>
                    <p><?php echo e($comment->comment_content); ?></p>
                </div>
                <form method="POST" action="<?php echo e(route('comments.destroy', $comment->comment_id)); ?>" onsubmit="return confirm('정말로 삭제하시겠습니까?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <?php if(Auth::id() === $comment->u_id): ?>
                    <button type="submit" class="delete-comment-btn">댓글 삭제</button>
                    <?php endif; ?>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>           
        <div class="detail_comment_insert">
        <form action="<?php echo e(route('comments', ['boardId' => $data->board_id])); ?>" method="post" id="commentForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="board_id" value="<?php echo e($data->board_id); ?>">
            <textarea name="comment_content" id="comment_content"></textarea>
            <button type="submit" class="detail_comment_insert_complete">입력</button>
        </form>

        </div>
</main>
<script src="/js/detail.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/detail.blade.php ENDPATH**/ ?>