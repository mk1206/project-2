

<?php $__env->startSection('title','Update'); ?>

<?php $__env->startSection('main'); ?>

<main class="insert_main">
	<div class="insert_hidden_container">
		<form class="detail_form" method="POST"  action="<?php echo e(route('board.update',['board'=>$data->board_id])); ?>" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<?php echo method_field('PUT'); ?>            
			<div class="insert_container">           
				<div class="insert_img">
				<?php $__currentLoopData = $data->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="detail_board_content">
						<img src="/board_img/<?php echo e($image->img_address); ?>" alt="Board Image" id="preview<?php echo e($key); ?>">
						<label for="file<?php echo e($key); ?>">
							<button type="button" onclick="openFile('file0')">파일변경</button>
						</label>
						<input type="file" name="board_img[]" id="file<?php echo e($key); ?>" style="display:none;" onchange="previewImage('file<?php echo e($key); ?>', 'preview<?php echo e($key); ?>')" accept="image/*">
						
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	</div>					
			<div class="insert_select_container">
				<select name="board" id="board" class="insert_select">
				
					<option value="<?php echo e($data->category_id); ?>"><?php echo e($data->category->category_name); ?></option>
				
					<option value="1">자유게시판</option>
					<option value="2">정보 게시판</option>
					<option value="3">친목 게시판</option>
					<option value="4">질문 게시판</option>
				</select>
			</div>		
			<div class="insert_input_container">
				<label for="u_title" class="">제목</label><br>
				<input type="text" class="insert_input" id="u_title" name="u_title" value="<?php echo e($data->board_title); ?>">			  
			</div>		
			<div class="insert_textarea_container">
				<label for="u_content" >내용</label><br>			  
				<textarea name="u_content" id="u_content" class="insert_textarea" ><?php echo e($data->board_content); ?></textarea>
			</div>		
			<div class="insert_hashtag_container">
				<label for="hashtag" class="label_hashtag">#해시태그</label>
				<input type="text" class="insert_hashtag" id="hashtag" name="hashtag" value="디테일에서 가져온값">			  
			</div>
		</div>
	</div>	
		<div class="insert_bottom_button">
		<a href="<?php echo e(url()->previous()); ?>"><button class="insert_btn">취소</button></a>		
			<button type="submit" class="insert_btn">수정완료</button>	
		</div>				
	</form>			
</main>
<script src="/js/update.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/update.blade.php ENDPATH**/ ?>