

<?php $__env->startSection('title', 'login'); ?>

<?php $__env->startSection('main'); ?>
	<div class="mini-container">
		<div class="lr-box">
			<form action="<?php echo e(route('login.post')); ?>" method="POST" id="login_form">
				<?php echo csrf_field(); ?>
				<span id="error_login_id" class="not-login-id">한글, 영문, 숫자로 4글자 이상 입력해주세요</span>
				<input type="text" class="login-input" placeholder="아이디" id="login_user_id" name="user_id">
				<input type="password" class="login-input" placeholder="비밀번호" id="login_user_password" name="user_password">
				<button type="button" class="login-button" onclick="logingo(); return false;">로그인</button>
				<br>
				<div class="display-flex lr-text">
					<a href="">아이디/비밀번호 찾기</a>
					<a href="/regist">회원가입</a>
				</div>
			</form>
			<input type="hidden" id="passwordError" value="<?php echo e($passwordError); ?>">
			
		</div>
	</div>
	<script src="../js/login.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2_project\team2\resources\views/login.blade.php ENDPATH**/ ?>