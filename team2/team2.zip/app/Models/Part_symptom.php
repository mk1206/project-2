<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Part_symptom extends Model
{
    use HasFactory;
    
    protected $primaryKey = 'part_symptom_id';
}
