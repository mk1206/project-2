<?php

return [
    'failed' => '제출하신 로그인 정보가 정확하지 않습니다.',
    'throttle' => ':seconds초 후에 다시 시도하세요.',
];
